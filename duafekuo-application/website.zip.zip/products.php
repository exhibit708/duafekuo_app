<?php
    include 'header2.php';
     ?>
<!DOCTYPE html>
<html>
    <head>
        <link rel="shortcut icon" href="img/lifestyleStore.png" />
        <title>duafekuo online Store</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
      
        <!-- External CSS -->
        <link rel="stylesheet" href="css/style.css" type="text/css">
        <link rel="icon" href="images/logo7.jpg.jpg">
    </head>
    <body>
         
          
<!-- customers review -->
<div class="container" style="margin-top: 153px;" data-aos="zoom-in-right">
<h4 class="text-center mt-5">SOME CUSTOMERS REVIEWS <SPan><i class="fas fa-grin-stars" style="color:gray;"></i></SPan></h4>
	<div class="row testimonial">

    <div class="col-sm-8 col-sm-offset-2">

    <img src="images/img1.jpg (2).jpg" class="img-responsive rounded-circle ml-5" style="width:20%;"> <span><i class="fab fa-facebook"></i></span>
    <small class="mt-2">Augustine Boadi-    <span class="text-muted">Programer</span> </small><br>
    <div>
      <i class="fas fa-star"></i>
      <i class="fas fa-star" ></i>
      <i class="fas fa-star" ></i>
      <i class="fas fa-star" ></i>
      <i class="fas fa-star" ></i>
    </div>
<p>Your products is very owesome and afodable.Duafekuo has given me best online shopping Experience I appreciate Your 
  Effort!</p>
<i class="fas fa-thumbs-up" style="color:gray;"></i>
<i class="fas fa-laugh" style="color:gray;"></i>
<span class="text-muted">@ Kumasi</span>
</div>
<div class="col-sm-8 col-sm-offset-2">

    <img src="images/tom.jpg.jpg" class="img-responsive rounded-circle ml-5" style="width:15%;"><span> <i class="fab fa-twitter"></i></span>
    <small class="mt-2">Thomas Nyarkor-    <span class="text-muted">Business Man</span> </small><br>
    <div>
      <i class="fas fa-star" style="color: yellow;"></i>
      <i class="fas fa-star" style="color: yellow;"></i>
      <i class="fas fa-star" style="color: yellow;"></i>
      <i class="fas fa-star" style="color: yellow;"></i>
      <i class="fas fa-star" style="color: yellow;"></i>
    </div>
<p>Your products is very owesome and afodable.Duafekuo has given me best online shopping Experience I appreciate Your 
  Effort!</p>
<i class="fas fa-thumbs-up" style="color:orange;"></i>
<i class="fas fa-laugh" style="color:orange"></i>
<span class="text-muted">@ Mankesim</span>
</div>
<div class="col-sm-8 col-sm-offset-2">

    <img src="images/stevo.jpg.jpg" class="img-responsive rounded-circle ml-5" style="width:20%;"><span> <i class="fab fa-twitter"></i></span>
    <small class="mt-2">Stephene Bowtway-    <span class="text-muted">DataBase Adminstrator</span> </small><br>
    <div>
      <i class="fas fa-star" style="color: yellow;"></i>
      <i class="fas fa-star" style="color: yellow;"></i>
      <i class="fas fa-star" style="color: yellow;"></i>
      <i class="fas fa-star" ></i>
      <i class="fas fa-star" ></i>
    </div>
<p>Your products is very owesome and afodable.Duafekuo has given me best online shopping Experience I appreciate Your 
  Effort!</p>
<i class="fas fa-thumbs-up" style="color:gray;"></i>
<i class="fas fa-hand-spock" style="color:gray;"></i>
<span class="text-muted">@ Takoradi</span>
</div>
<div class="col-sm-8 col-sm-offset-2">

    <img src="images/me.jpeg.jpg" class="img-responsive rounded-circle ml-5" style="width:20%;"><span> <i class="fab fa-instagram"></i></span>
    <small class="mt-2">Osacr Boadi-    <span class="text-muted">Student @ uew</span> </small><br>
    <div>
      <i class="fas fa-star" style="color: yellow;"></i>
      <i class="fas fa-star" style="color: yellow;"></i>
      <i class="fas fa-star" style="color: yellow;"></i>
      <i class="fas fa-star" style="color: yellow;"></i>
      <i class="fas fa-star" style="color: yellow;"></i>
    </div>
<p>Your products is very owesome and afodable.Duafekuo has given me best online shopping Experience I appreciate Your 
  Effort!</p>
<i class="fas fa-thumbs-up" style="color:yellow;"></i>
<i class="fas fa-grin-alt" style="color:yellow;"></i>
<span class="text-muted">@ Takoradi</span>
</div>
<div class="col-sm-8 col-sm-offset-2">

    <img src="images/man2.jpeg.webp" class="img-responsive rounded-circle ml-5" style="width:30%;"><span> <i class="fab fa-twitter"></i></span>
    <small class="mt-2">Narbi Richard-    <span class="text-muted">enterprenuear</span> </small><br>
    <div>
      <i class="fas fa-star" style="color: yellow;"></i>
      <i class="fas fa-star"></i>
      <i class="fas fa-star" style="color: yellow;"></i>
      <i class="fas fa-star"></i>
      <i class="fas fa-star" style="color: yellow;"></i>
    </div>
<p>IYour products is very owesome and afodable.Duafekuo has given me best online shopping Experience I appreciate Your 
  Effort!</p>
<i class="fas fa-thumbs-up" style="color:gray;"></i>
<i class="fas fa-laugh" style="color:gray;"></i>
<span class="text-muted">@ kumasi</span>
</div>
<div class="col-sm-8 col-sm-offset-2">

    <img src="images/woman4.jpeg.jpeg" class="img-responsive rounded-circle ml-5" style="width:30%;"><span> <i class="fab fa-facebook"></i></span>
    <small class="mt-2">Mary Amoaben Princess-    <span class="text-muted">Student @ Uew</span> </small><br>
    <div>
      <i class="fas fa-star" ></i>
      <i class="fas fa-star" ></i>
      <i class="fas fa-star" ></i>
      <i class="fas fa-star" ></i>
      <i class="fas fa-star" ></i>
    </div>
<p>Your products is very owesome and afodable.Duafekuo has given me best online shopping Experience I appreciate Your 
  Effort!</p>
<i class="fas fa-thumbs-up" style="color:gray;"></i>
<i class="fas fa-laugh" style="color:gray;"></i>
<span class="text-muted">@ kumasi</span>
</div>


	</div>
</div>
            <div class="container-fluid" data-aos="fade-right">
              <div class="row">
                <div class="col">
               <ul class="slider">
               <li id="bannerImage4">
               <div class="container">
                   <center>
                     
                   <h4 class="text-center text-white">start &nbsp;<span class="typed text-success"></span></h4>
                  
                   </center>
               </div>
           </li>
         
    
               </ul>
               
                  
                </div>
              </div>
            </div>
 <!-- product details -->
 <?php 

//Process Authentication 
include 'php/includes/dbh.inc.php';
//Load product data
if (isset($_GET['pid'])) {
    //Get product id
    $pid = $_GET['pid'];
    //Return product details from base
    //SQL
    $sql = "SELECT * FROM product WHERE productId = '$pid'";
    //Query
    $query = mysqli_query($connect, $sql) or die('Cant connect to base');
    //Fetch product data
    $result = mysqli_fetch_assoc($query);
    //log
    // echo var_dump($result);
    // $cart = $result('cartegory');
}


 ?>


<!-- ========================= SECTION CONTENT ========================= -->
<section class="section-content bg-white padding-y">
<div class="container " data-aos="zoom-out-up">

<!-- ============================ ITEM DETAIL ======================== -->
	<div class="row">
		<aside class="col-md-6">
      <div class="card">
        <article class="gallery-wrap"> 
        <div class="exzoom" id="exzoom">
  <!-- Images -->
  <div class="exzoom_img_box">
    <ul class='exzoom_img_ul'>
      <li><img src="images/uploads/<?=$result['productImage']?>"/></li>
      <li><img src="images/uploads/<?=$result['productImage']?>"/></li>
      <li><img src="images/uploads/<?=$result['productImage']?>"/></li>
      <li><img src="images/uploads/<?=$result['productImage']?>"/></li>
      <p>product images</p>
    </ul>
  </div>
  <!-- <a href="https://www.jqueryscript.net/tags.php?/Thumbnail/">Thumbnail</a> Nav-->
  <div class="exzoom_nav"></div>
  <!-- Nav Buttons -->
  <p class="exzoom_btn">
      <a href="javascript:void(0);" class="exzoom_prev_btn"> < </a>
      <a href="javascript:void(0);" class="exzoom_next_btn"> > </a>
  </p>
</div>
          
        </article> 
      </div> <!-- card.// -->
		</aside>
		<main class="col-md-6">
<article class="product-info-aside">

<h2 class="title mt-3"><?php echo $result['productName']; ?></h2>

<div class="rating-wrap my-3">
	<ul class="rating-stars">
		
		<li>
			<i class="fa fa-star"></i> 
      <i class="fa fa-star"></i> 
			<i class="fa fa-star"></i>
       <i class="fa fa-star"></i> 
			<i class="fa fa-star"></i> 
		</li>
	</ul>
	<small class="label-rating text-muted">rate this product</small>
</div> <!-- rating-wrap.// -->
<?php
$price=$result['productPrice'];
?>
<div class="mb-3"> 
	<var class="price h4">₵&nbsp;<?= number_format($price,3); ?></var> 
</div> <!-- price-detail-wrap .// -->

	 <div class="content">
    <?php echo html_entity_decode($result['productDesc']); ?>
   </div>

	<div class="form-row  mt-4">
  <!-- col.// -->
      <div class="form-group col-md">
        <div > 
        <?php if(!isset( $_SESSION['uid'])){ ?>
                                        <p><a href="login.php" role="button" class="btn btn-primary btn-block">Buy Now <i class="fas fa-shopping-cart"></i>&nbsp;</a></p>
                                        <?php
                                        }
                                      
                                                else{
                                                  ?>
                                                  <a href="cart_add.php?id=<?=$result['productId']?>" class="btn btn-block btn-primary" name="add" value="add" >Add to cart &nbsp; <i class="fas fa-shopping-cart"></i></a> 
                                                  <?php

                                                }

                                        
                                        
                                        ?> 
        </div>
      </div> <!-- col.// -->
  
	</div> <!-- row.// -->

</article> <!-- product-info-aside .// -->
		</main> <!-- col.// -->
	</div> <!-- row.// -->

<!-- ================ ITEM DETAIL END .// ================= -->


</div> <!-- container .//  -->
</section>
<!-- ========================= SECTION CONTENT END// ========================= -->


	

    
			<!-- container -->
			<div class="container" data-aos="flip-left">
				<!-- row -->
        <div class="col-md-12">
						<div class="section-title">
							<div class="section-nav">
              
								<ul class="section-tab-nav tab-nav">
                  <?php
                $cartegory=$result['cartegory'];
                ?>
									<li class="active"><a data-toggle="tab" href="#tab1">Other Related <span class="text-primary"><?=  $cartegory?>&nbsp;</span>Products </a></li>
								
								</ul>
							</div>
						</div>
					</div>
				<div class="row">
		
					<!-- /section title -->

					<!-- Products tab & slick -->
				
					

						
									
										<!-- product -->
										<?php
                    include 'php/includes/dbh.inc.php';
                   
                    
					$product_query = "SELECT * FROM product where cartegory like '%$cartegory%' ORDER BY productId DESC limit 30;";
                $run_query = mysqli_query($connect,$product_query);
                $results=mysqli_num_rows($run_query);

                    while($row = mysqli_fetch_array($run_query)){
						$pro_id    = $row['productId'];
                        $pro_name   = $row['productName'];
                        $pro_price = $row['productPrice'];
                        $pro_image = $row['productImage'];
                       $pro_desc = $row['productDesc'];
                         ?>
                   	<div class="col-xl-3 col-lg-3 col-md-4 col-6 my-5 mainn mainn-raised">          
								<div class='product'>
									<a href='products.php?pid=<?= $pro_id ;?>'><div class='product-img'>
										<img src='images/uploads/<?=$pro_image?> ' style='max-height: 170px;' alt=''>
										<div class='product-label'>
											<span class='sale'>-30%</span>
											<span class='new'>NEW</span>
										</div>
									</div></a>
									<div class='product-body'>
										<p class='product-category'><?=  $pro_name;?></p>
										<h4 class='product-price header-cart-item-info'>₵&nbsp;<?=$pro_price; ?><del class='product-old-price'>₵0.00</del></h4>
										<div class='product-rating'>
											<i class='fa fa-star'></i>
											<i class='fa fa-star'></i>
											<i class='fa fa-star'></i>
											<i class='fa fa-star'></i>
											<i class='fa fa-star'></i>
										</div>
									</div>
									<div class='add-to-cart'>
                  <?php if(!isset( $_SESSION['uid'])){ ?>
                                        <p><a href="login.php" role="button" class="btn btn-primary btn-block">Buy Now <i class="fas fa-shopping-cart"></i>&nbsp;</a></p>
                                        <?php
                                        }
                                      
                                                else{
                                                  ?>
                                                  <a href="cart_add.php?id=<?=$row['productId']?>" class="btn btn-block btn-primary" name="add" value="add" >Add to cart &nbsp; <i class="fas fa-shopping-cart"></i></a> 
                                                  <?php

                                                }

                                        
                                        
                                        ?>
									</div>
								</div>
                </div>                
							
                        
			<?php
		}
        ;
      

?>
										
										<!-- /product -->
								
							
							
							
						
				
				
				<!-- /row -->
			</div>
      </div>
      
	<!-- ======= Hero Section ======= -->
  <section id="hero">

<div class="container">
  <div class="row justify-content-between">
    <div class="col-lg-7 pt-5 pt-lg-0 order-2 order-lg-1 d-flex align-items-center">
      <div data-aos="zoom-out">
        <h1>SHOP AT YOUR CONVINENTS HOME @<span>DUAFEKUO</span></h1>
        <h2>"Consume Green" and "Patronize Green"...</h2>
        <a href="register.php" class="btn btn-outline-success btn-rounded"
  data-mdb-ripple-color="success">sign-up now.. &nbsp; <i class="fas fa-shopping-cart"></i></a>
       
      </div>
    </div>
    <div class="col-lg-4 order-1 order-lg-2 hero-img" data-aos="zoom-out" data-aos-delay="300">
      <img src="images/design2.jpg.png" class="img-fluid animated" alt="">
    </div>
  </div>
</div>

<svg class="hero-waves" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 24 150 28 " preserveAspectRatio="none">
  <defs>
    <path id="wave-path" d="M-160 44c30 0 58-18 88-18s 58 18 88 18 58-18 88-18 58 18 88 18 v44h-352z">
  </defs>
  <g class="wave1">
    <use xlink:href="#wave-path" x="50" y="3" fill="rgba(255,255,255, .1)">
  </g>
  <g class="wave2">
    <use xlink:href="#wave-path" x="50" y="0" fill="rgba(255,255,255, .2)">
  </g>
  <g class="wave3">
    <use xlink:href="#wave-path" x="50" y="9" fill="#fff">
  </g>
</svg>

</section><!-- End Hero -->


    
			<!-- container -->
			<div class="container" data-aos="zoom-in">
				<!-- row -->
        <div class="col-md-12">
						<div class="section-title">
							<div class="section-nav">
              
								<ul class="section-tab-nav tab-nav">
                
									<li class="active"><a data-toggle="tab" href="#tab1">Recomended</a></li>
								
								</ul>
							</div>
						</div>
					</div>
				<div class="row">
		
					<!-- /section title -->

					<!-- Products tab & slick -->
				
					

						
									
										<!-- product -->
										<?php
                    include 'php/includes/dbh.inc.php';
                   
                    
					$product_query = "SELECT * FROM product  ORDER BY productId DESC limit 20;";
                $run_query = mysqli_query($connect,$product_query);
                $results=mysqli_num_rows($run_query);

                    while($row = mysqli_fetch_array($run_query)){
						$pro_id    = $row['productId'];
                        $pro_name   = $row['productName'];
                        $pro_price = $row['productPrice'];
                        $pro_image = $row['productImage'];
                       $pro_desc = $row['productDesc'];
                         ?>
                   	<div class="col-xl-3 col-lg-3 col-md-4 col-6 my-5 mainn mainn-raised">          
								<div class='product'>
									<a href='products.php?pid=<?= $pro_id ;?>'><div class='product-img'>
										<img src='images/uploads/<?=$pro_image?> ' style='max-height: 170px;' alt=''>
										<div class='product-label'>
											<span class='sale'>-30%</span>
											<span class='new'>NEW</span>
										</div>
									</div></a>
									<div class='product-body'>
										<p class='product-category'><?=  $pro_name;?></p>
										<h4 class='product-price header-cart-item-info'>₵&nbsp;<?=$pro_price; ?><del class='product-old-price'>₵0.00</del></h4>
										<div class='product-rating'>
											<i class='fa fa-star'></i>
											<i class='fa fa-star'></i>
											<i class='fa fa-star'></i>
											<i class='fa fa-star'></i>
											<i class='fa fa-star'></i>
										</div>
									</div>
									<div class='add-to-cart'>
                  <?php if(!isset( $_SESSION['uid'])){ ?>
                                        <p><a href="login.php" role="button" class="btn btn-primary btn-block">Buy Now <i class="fas fa-shopping-cart"></i>&nbsp;</a></p>
                                        <?php
                                        }
                                      
                                                else{
                                                  ?>
                                                  <a href="cart_add.php?id=<?=$row['productId']?>" class="btn btn-block btn-primary" name="add" value="add" >Add to cart &nbsp; <i class="fas fa-shopping-cart"></i></a> 
                                                  <?php

                                                }

                                        
                                        
                                        ?>
									</div>
								</div>
                </div>                
							
                        
			<?php
		}
        ;
      

?>
										
										<!-- /product -->
								
							
							
							
						
				
				
				<!-- /row -->
			</div>
      </div>
<!-- =============== counter of our review =============== -->
<div class="container">
<div class="row row-cols-1 row-cols-md-2 g-4">
  <div class="col" data-aos="fade-up-right">
  <div class="card count-box " style="background:#03644F;">
  <div class="card-body ">
    <h5 class="card-title text-white text-center">PRODUCTS IN OUR SHOP</h5>
    <p class="card-text text-center">
    <i class="fas fa-box-open fa-3x" style="color:#fff;"></i>
    </p>
    <span class="counter text-white text-center display-5 text-uppercase" style="font-weight:bold;">34,00</span>
  </div>
</div>
</div>
<div class="col" data-aos="fade-down-left">
  <div class="card count-box " style="background:#03644F;">
  <div class="card-body ">
    <h5 class="card-title text-white text-center">REVIEW</h5>
    <p class="card-text text-center">
    <i class="fas fa-star fa-3x" style="color:yellow;"></i>
    </p>
    <p class="counter text-white ml-5 display-5 text-uppercase" style="font-weight:bold;">4.7</p>
  </div>
</div>
</div>
<div class="col" data-aos="flip-left">
  <div class="card count-box " style="background:#03644F;">
  <div class="card-body ">
    <h5 class="card-title text-white text-center">DELIVERY SERVICE</h5>
    <p class="card-text text-center">
    <i class="fas fa-car fa-3x" style="color:#fff;"></i>
    </p>
    <p class="counter text-white ml-5 display-5 text-uppercase" style="font-weight:bold;">10,000 </p>
  </div>
</div>
</div>
  <div class="col" data-aos="flip-right">
  <div class="card count-box" style="background:#03644F;">
  <div class="card-body ">
    <h5 class="card-title text-white text-center">CUSTOMER CARE</h5>
    <p class="card-text text-center">
    <i class="fas fa-bullhorn fa-3x" style="color:#fff;"></i>
    </p>
    <p class="counter text-white ml-5 display-5 text-uppercase" style="font-weight:bold;">100 </p>

    
    
  </div>
</div>
</div>
 
</div>

</div>

			<!-- container -->
			<div class="container">
	
				<!-- row -->
				<div class="row owl-carousel owl-theme">
					<div class="col col-xl-3 col-lg-3 col-md-4 col-6" data-aos="zoom-out-down">
						<div class="section-title">
						
							<div class="section-nav">
								<div id="slick-nav-3" class="products-slick-nav"></div>
							</div>
						</div>
						

						<div class="products-widget-slick" data-nav="#slick-nav-3">
							<div id="get_product_home">
								<!-- product widget -->
	
	
								<!-- product widget -->
							</div>
							<?php
		//Looping all products in database
		//SQL
		$sql = "SELECT * FROM product WHERE cartegory like '%Cutlery%' ORDER BY productId DESC limit 5; ";
		//QUERY
		$query = mysqli_query($connect, $sql);
		//Return all result in an array
		while ($row = mysqli_fetch_assoc($query)) {
			//Now loop through data
      $pro_id    = $row['productId'];
      $pro_name   = $row['productName'];
      $pro_price = $row['productPrice'];
      $pro_image = $row['productImage'];
      $pro_desc = $row['productDesc'];
      $discount=$row['discount'];
	  ?>

							<div id="get_product_home2">
								<!-- product widget -->
								<div class="product-widget">
									<div class="product-img">
										<img src="images/uploads/<?=$pro_image?>" alt="">
									</div>
									<div class="product-body">
										<p class="product-category">Top Cutlery</p>
										<h3 class="product-name"><a href='products.php?pid=<?= $pro_id ;?>'><?=$pro_name;?></a></h3>
										<h4 class="product-price">₵&nbsp;<?= $pro_price; ?><del class="product-old-price"><?=$discount;?></del></h4>
									</div>
								</div>
								<!-- /product widget -->

						
								<!-- /product widget -->
								<!-- product widget -->
							</div>
							<?php
		}
		?>
						</div>
					</div>

					<div class="col col-xl-3 col-lg-3 col-md-4 col-6" data-aos="fade-left">
						<div class="section-title">
							
							<div class="section-nav">
								<div id="slick-nav-4" class="products-slick-nav"></div>
							</div>
						</div>

						<div class="products-widget-slick" data-nav="#slick-nav-4">
							<div>
							<?php
		//Looping all products in database
		//SQL
		$sql = "SELECT * FROM product WHERE cartegory like '%Appliances%' ORDER BY productId DESC limit 5 ";
		//QUERY
		$query = mysqli_query($connect, $sql);
		//Return all result in an array
		while ($row = mysqli_fetch_assoc($query)) {
			//Now loop through data
      $pro_id    = $row['productId'];
      $pro_name   = $row['productName'];
      $pro_price = $row['productPrice'];
      $pro_image = $row['productImage'];
      $pro_desc = $row['productDesc'];
      $discount=$row['discount'];
	  ?>
								<!-- product widget -->
								<div class="product-widget">
									<div class="product-img">
									<img src="images/uploads/<?=$pro_image?>" alt="">
									</div>
									<div class="product-body">
										<p class="product-category">Top Appliances</p>
										<h3 class="product-name"><a href='products.php?pid=<?= $pro_id ;?>'><?=$pro_name;?></a></h3>
										<h4 class="product-price">₵&nbsp;<?= $pro_price; ?><del class="product-old-price"><?=$discount;?></del></h4>
									</div>
								</div>
								<?php
		}
		?>
							
								<!-- product widget -->
							</div>

							<div>

								<!-- product widget -->
							</div>
						</div>
					</div>

					

					<div class="col col-xl-3 col-lg-3 col-md-4 col-6" data-aos="fade-right">
						<div class="section-title">
							
							<div class="section-nav">
								<div id="slick-nav-5" class="products-slick-nav"></div>
							</div>
						</div>

						<div class="products-widget-slick" data-nav="#slick-nav-5">
							<div>
							<?php
		//Looping all products in database
		//SQL
		$sql = "SELECT * FROM product WHERE cartegory like '%Utensils%' ORDER BY productId DESC limit 5;";
		//QUERY
		$query = mysqli_query($connect, $sql);
		//Return all result in an array
		while ($row = mysqli_fetch_assoc($query)) {
			//Now loop through data
      $pro_id    = $row['productId'];
      $pro_name   = $row['productName'];
      $pro_price = $row['productPrice'];
      $pro_image = $row['productImage'];
      $pro_desc = $row['productDesc'];
      $discount=$row['discount'];
	  ?>


								<!-- product widget -->
								<div class="product-widget">
									<div class="product-img">
									<img src="images/uploads/<?=$pro_image?>" alt="">
									</div>
									<div class="product-body">
										<p class="product-category">Top Utensils</p>
										<h3 class="product-name"><a href='products.php?pid=<?= $pro_id ;?>'><?=$pro_name;?></a></h3>
										<h4 class="product-price">₵&nbsp;<?= $pro_price; ?> <del class="product-old-price"><?=$discount;?></del></h4>
									</div>
								</div>
								<?php
		}
		?>
								<!-- /product widget -->

		
								<!-- product widget -->
							</div>

						
						</div>
					</div>

          <div class="col col-xl-3 col-lg-3 col-md-4 col-6">
						<div class="section-title">
							
							<div class="section-nav">
								<div id="slick-nav-5" class="products-slick-nav"></div>
							</div>
						</div>

						<div class="products-widget-slick" data-nav="#slick-nav-5">
							<div>
							<?php
		//Looping all products in database
		//SQL
		$sql = "SELECT * FROM product WHERE cartegory like '%Decor/Crafts%' ORDER BY productId DESC limit 5;";
		//QUERY
		$query = mysqli_query($connect, $sql);
		//Return all result in an array
		while ($row = mysqli_fetch_assoc($query)) {
			//Now loop through data
      $pro_id    = $row['productId'];
      $pro_name   = $row['productName'];
      $pro_price = $row['productPrice'];
      $pro_image = $row['productImage'];
      $pro_desc = $row['productDesc'];
      $discount=$row['discount'];
	  ?>


								<!-- product widget -->
								<div class="product-widget">
									<div class="product-img">
									<img src="images/uploads/<?=$pro_image?>" alt="">
									</div>
									<div class="product-body">
										<p class="product-category">Decor/Crafts</p>
										<h3 class="product-name"><a href='products.php?pid=<?= $pro_id ;?>'><?=$pro_name;?></a></h3>
										<h4 class="product-price">₵&nbsp;<?= $pro_price; ?> <del class="product-old-price"><?=$discount;?></del></h4>
									</div>
								</div>
								<?php
		}
		?>
								<!-- /product widget -->

		
								<!-- product widget -->
							</div>

						
						</div>
					</div>

          
          <div class="col col-xl-3 col-lg-3 col-md-4 col-6" data-aos="flip-left">
						<div class="section-title">
							
							<div class="section-nav">
								<div id="slick-nav-5" class="products-slick-nav"></div>
							</div>
						</div>

						<div class="products-widget-slick" data-nav="#slick-nav-5">
							<div>
							<?php
		//Looping all products in database
		//SQL
		$sql = "SELECT * FROM product WHERE cartegory like '%Packages/Disposables%' ORDER BY productId DESC limit 5;";
		//QUERY
		$query = mysqli_query($connect, $sql);
		//Return all result in an array
		while ($row = mysqli_fetch_assoc($query)) {
			//Now loop through data
      $pro_id    = $row['productId'];
      $pro_name   = $row['productName'];
      $pro_price = $row['productPrice'];
      $pro_image = $row['productImage'];
      $pro_desc = $row['productDesc'];
      $discount=$row['discount'];
	  ?>


								<!-- product widget -->
								<div class="product-widget">
									<div class="product-img">
									<img src="images/uploads/<?=$pro_image?>" alt="">
									</div>
									<div class="product-body">
										<p class="product-category">Packages/Disposables</p>
										<h3 class="product-name"><a href='products.php?pid=<?= $pro_id ;?>'><?=$pro_name;?></a></h3>
										<h4 class="product-price">₵&nbsp;<?= $pro_price; ?> <del class="product-old-price"><?=$discount;?></del></h4>
									</div>
								</div>
								<?php
		}
		?>
								<!-- /product widget -->

		
								<!-- product widget -->
							</div>

						
						</div>
					</div>

				</div>
	
				<!-- /row -->
			</div>
	

      <br><br><br><br>
			
 <!-- Footer -->
<footer class="text-center text-lg-start text-white" style="background:#03644F;">
  <!-- Section: Social media -->
  <section
    class="d-flex justify-content-center justify-content-lg-between p-4 border-bottom"
  >
    <!-- Left -->
    <div class="me-5 d-none d-lg-block">
      <span>Get connected with us on social networks:</span>
    </div>
    <!-- Left -->

    <!-- Right -->
    <div>
      <a href="" class="me-4 text-reset">
        <i class="fab fa-facebook-f"></i>
      </a>
      <a href="" class="me-4 text-reset">
        <i class="fab fa-twitter"></i>
      </a>
      <a href="" class="me-4 text-reset">
        <i class="fab fa-google"></i>
      </a>
      <a href="" class="me-4 text-reset">
        <i class="fab fa-instagram"></i>
      </a>
      <a href="" class="me-4 text-reset">
        <i class="fab fa-linkedin"></i>
      </a>
   
    </div>
    <!-- Right -->
  </section>
  <!-- Section: Social media -->

  <!-- Section: Links  -->
  <section class="">
    <div class="container text-center text-md-start mt-5">
      <!-- Grid row -->
      <div class="row mt-3">
        <!-- Grid column -->
        <div class="col-md-3 col-lg-4 col-xl-3 mx-auto mb-4">
          <!-- Content -->
          <h6 class="text-uppercase fw-bold mb-4 text-white">
            <i class="fas fa-gem me-3" ></i>Duafekuo store
          </h6>
          <p>
           Get all kinds of quality products @ affodable price
		   
          </p>
        </div>
        <!-- Grid column -->

        <!-- Grid column -->
        <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mb-4">
          <!-- Links -->
          <h6 class="text-uppercase fw-bold mb-4 text-white">
          Support Us!
          </h6>
          <p>
            <a href="#!" class="text-reset">Investors</a>
          </p>
          <p>
            <a href="#!" class="text-reset"><i class="fas-fa-donate"></i> &nbsp; donation</a>
          </p>
          <p>
            <a href="#!" class="text-reset">Goals</a>
          </p>
          <p>
            <a href="#!" class="text-reset">Vision</a>
          </p>
        </div>
        <!-- Grid column -->

        <!-- Grid column -->
        <div class="col-md-3 col-lg-2 col-xl-2 mx-auto mb-4">
          <!-- Links -->
          <h6 class="text-uppercase fw-bold mb-4 text-white">
            Products
          </h6>
          <p>
            <a href="#!" class="text-reset">Cutlery</a>
          </p>
          <p>
            <a href="#!" class="text-reset">Appliances</a>
          </p>
          <p>
            <a href="#!" class="text-reset">Utensils</a>
          </p>
          <p>
            <a href="#!" class="text-reset">Decor/Crafts</a>
          </p>
          <p>
            <a href="#!" class="text-reset">Packages/Disposables</a>
          </p>
        </div>
        <!-- Grid column -->

        <!-- Grid column -->
        <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4">
          <!-- Links -->
          <h6 class="text-uppercase fw-bold mb-4 text-white">
            Contact
          </h6>
          <p><i class="fas fa-home me-3"></i> Kumasi ,Ghana</p>
          <p>
            <i class="fas fa-envelope me-3"></i>
			duafekuoventures@gmail.com
          </p>
          <p><i class="fas fa-phone me-3"></i> + 233 24 582 8985</p>
          <p><i class="fas fa-print me-3"></i>+ 233 24 582 8985</p>
        </div>
        <!-- Grid column -->
      </div>
      <!-- Grid row -->
    </div>
  </section>
  <!-- Section: Links  -->

  <!-- Copyright -->
  <div class="text-center p-4" style="background-color: rgba(0, 0, 0, 0.05);">
    © 2021 Copyright:
    <a class="text-reset fw-bold" href="">Duafekuo.com</a>
  </div>
  <!-- Copyright -->
</footer>
<!-- Footer -->
        </div>
        <!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/61059f01d6e7610a49adf098/1fbuva8vm';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->
<!-- typed javascript -->
<script src="js/typed.min.js"></script>

<script>

var typed = new Typed('.typed', {
  strings:['cheep','affodable','@','duafekuo','duafekuo','stores'],
  typeSpeed: 250,
  backspeed:250,
  loop:true
});



</script>
<script src="https://unpkg.com/aos@next/dist/aos.js"></script>
  <script>
  $(document).ready(function(){
    AOS.init();
  })  
  </script>
<!-- MDB -->
<script
  type="text/javascript"
  src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/3.6.0/mdb.min.js"
></script>
<script src="https://code.jquery.com/jquery-1.12.4.min.js" 
        integrity="sha384-nvAa0+6Qg9clwYCGGPpDQLVpLNn0fRaROjHqs13t4Ggj3Ez50XnGQqc/r8MhnRDZ" 
        crossorigin="anonymous"></script>
<script src="js/jquery.exzoom.js"></script>
<!-- jquery slick carousel -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.js" integrity="sha512-XtmMtDEcNz2j7ekrtHvOVR4iwwaD6o/FUJe6+Zq+HgcCsk3kj4uSQQR8weQ2QVj1o0Pk6PwYLohm206ZzNfubg==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>


<!-- testimonial spl_autoload_register -->
<script>
	$('.testimonial').slick({
  dots:true,
  infinite:true,
  speed: 300,
  slidesToShow:3,
  slidesToScroll: 1,
  autoplay: true,
  autoplaySpeed: 2000,
 
//   prevArrow:"<span class='prev-arrow'><i class='fas fa-angle-left'></i></span>",
//   nextArrow:"<span class='next-arrow'><i class='fas fa-angle-right'></i></span>",
  responsive: [
    {
      breakpoint: 1024,
      settings: {
        slidesToShow: 3,
        slidesToScroll: 1,
        infinite: true,
        dots: true
	
      }
    },
    {
      breakpoint: 600,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 1
      }
    },
    {
      breakpoint: 480,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1
      }
    }
    // You can unslick at a given breakpoint now by adding:
    // settings: "unslick"
    // instead of a settings object
  ]
});

</script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js" integrity="sha512-bPs7Ae6pVvhOSiIcyUClR7/q2OAsRiovw4vAkX+zJbw3ShAeeqezq50RIIcIURq7Oa20rW2n2q+fyXBNcU9lrw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script>
$(document).ready(function() {
 
  $('.owl-carousel').owlCarousel({
    loop:true,
    margin:10,
    autoplay:true,
    dots:false,
    nav:true,
    itemsDeskto : [1199,3],
      itemsDesktopSmall : [979,3],
    responsive:{
        0:{
            items:2
        },
        600:{
            items:3
        },
        1000:{
            items:3
           
        }
    }
})

});


 
</script>
<script>


$(function(){

$("#exzoom").exzoom({

  // thumbnail nav options
  "navWidth": 60,
  "navHeight": 60,
  "navItemNum": 5,
  "navItemMargin": 7,
  "navBorder": 1,

  // autoplay
  "autoPlay": true,

  // autoplay interval in milliseconds
  "autoPlayTimeout": 2000
  
});

});
</script>

<!-- bootsrap s5 -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>

    </body>
</html>
